﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour
{
    public float shootForce;
    public Transform shootPos;
    public GameObject bulletPrefab;
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            GameObject bullet;
            bullet = Instantiate(bulletPrefab, shootPos.position, shootPos.rotation);
            Destroy(bullet, 5f);
            bullet.GetComponent<Rigidbody>().AddForce(shootPos.forward * shootForce, ForceMode.Impulse);
        }
    }
}
