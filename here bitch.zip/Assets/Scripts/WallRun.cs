﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallRun : MonoBehaviour
{
    Transform mainCam;
    public float duration, camTiltAngle;
    public bool rightSide;
    bool wallRunning;
    Rigidbody playerRB;
    private void Start()
    {
        mainCam = Camera.main.transform;
        if (rightSide)
            camTiltAngle *= -1;
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerRB = other.GetComponent<Rigidbody>();
            StartWallRun();
            Invoke(nameof(EndWallRun), duration);
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerRB = other.GetComponent<Rigidbody>();
            EndWallRun();
        }
    }
    void StartWallRun()
    {
        wallRunning = true;
        playerRB.useGravity = false;
        mainCam.Rotate(new Vector3(0, 0, camTiltAngle));
    }
    void EndWallRun()
    {
        if (wallRunning)
            mainCam.Rotate(new Vector3(0, 0, -camTiltAngle));
        wallRunning = false;
        playerRB.useGravity = true;
    }
}
